#!/usr/local/bin/ruby -w

# fastercsv.rb
#
#  Created by James Edward Gray II on 2006-04-01.
#  Copyright 2006 Gray Productions. All rights reserved.
# 
# This file is just another name for faster_csv.rb.

require "faster_csv"
