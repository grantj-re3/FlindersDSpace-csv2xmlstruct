Import ERA - Workflow Testing
-----------------------------

It is a little difficult to devise a workflow test environment
which will be repeatable for everybody (or even repeatable for
the same person) because each time items, collections and
communities are created they will be assigned different database
table 'id' fields and different handles. So the procedure below
resembles a case study more than a repeatable test. I hope it is
useful in some way!

Group 1 steps (below) create a test environment:
- 1a_mkPrevStructs
- 1b_populatePrev
- 1c_exportPrev
- 1d_createRmisSafCsv

After that, follow the documented workflow and apply it to the
test environment which you have just created.

Group 2 steps add new items (from your simulated Research MIS)
into the target ERA reporting-year:
- 2a_mkTargetStruct
- 2b_extractPrevRmids
- 2c_safPluck
- 2d_mkimport

Group 3 steps map any appropriate items to multiple collections:
- 3a_rmcsv2hdlcsv
- 3b_erabme_multicollections


Environment
-----------

The table below represents the communities and collections used
in this test. Communities and collections in the first row (ie.
Non-ERA 0000) were created manually in the DSpace web user interface.
See 1a_mkPrevStructs/result/README for name details.
Communities and collections in rows 2 and 3 (ie. ERA 1938 and ERA
1962) are created in the group 1 steps mentioned above. Communities
and collections in the last row (ie. ERA 1982) were created in the
workflow process (ie. group 2 steps above).

Community  name | Collection names | Description
----------------|------------------|------------
Non-ERA 0000    | 9998,9999        | Other/Previous ERA reporting-year
ERA 1938        | 0101,0102,0303   | Other/Previous ERA reporting-year
ERA 1962        | 0101,0102,0303   | Other/Previous ERA reporting-year
ERA 1982        | 0101,0102,0303   | Target ERA reporting-year

Each row in the table below represents a research publication, hence
each has an ID (RMID) assigned by your Research MIS system. Entries
in the "Existing coll" column show publications which already
exist as an item within a DSpace collection. Entries in the "Target coll"
column show publications sent from your Research MIS system for
loading into DSpace (via this suite of programs).


Existing coll | Target coll    | numCollections | RMID        | Title
--------------|----------------|----------------|-------------|------
00.9998       | -              | 1+0=1          | fake0001001 | Category 0; Test 1; numCollections 1
38.0101       | -              | 1+0=1          | fake0002001 | Category 0; Test 2; numCollections 1
All_8         | -              | 8+0=8          | fake0003008 | Category 0; Test 3; numCollections 8
--------------|----------------|----------------|-------------|------
00.9998       | 82.0101        | 1+1=2          | fake1001002 | Category 1; Test 1; numCollections 2
38.0101       | 82.0101        | 1+1=2          | fake1002002 | Category 1; Test 2; numCollections 2
All_8         | 82.0101        | 8+1=9          | fake1003009 | Category 1; Test 3; numCollections 9
All_8         | All_3          | 8+3=11         | fake2001011 | Category 2; Test 1; numCollections 11
--------------|----------------|----------------|-------------|------
-             | 82.0101        | 0+1=1          | fake0004001 | Category 0; Test 4; numCollections 1
-             | 82.[0102,0101] | 0+2=2          | fake2002002 | Category 2; Test 2; numCollections 2
-             | All_3          | 0+3=3          | fake2003003 | Category 2; Test 3; numCollections 3

Where Existing/Target coll has the following meaning.
  00.9998 = collection 9998 within [Non-ERA 00]00 community.
  38.0101 = collection 0101 within [ERA 19]38 community.
  82.[0101,0102] = collections 0101,0102 within [ERA 19]82 community.

All_8 = All 8 collections in "Other/Previous ERA reporting-year", ie.
  00.[9998,9999], 38.[0101,0102,0303], 62.[0101,0102,0303]
All_3 = All 3 collections in "Target ERA reporting-year", ie. 82.[0101,0102,0303]

The numCollections column shows:
  E + T = N
where:
  E = The number of collections which the item already belongs to (before workflow processing)
  T = The number of collections which the item belongs to within the target year (1982)
  N = The total number of collections which the item will belong to once the workflow is completed

Category 0 = items which do not need mapping to multiple collections.
Category 1 = items which need mapping due to 1 item in target year and 1 or more already in DSpace.
Category 2 = items which need mapping due to 2 or more items in target year (and 0 or more already in DSpace).

For ease of viewing in DSpace (where the title is visible on many
screens but the RMID is not) the title and RMID are related as follows:
  fakeCTTTNNN = Category C; Test TTT; numCollections NNN

For example:
  fake1003009 = Category 1; Test 3; numCollections 9


Workflow
--------

To follow the workflow for this case study:
- read README.md in the top directory of this project (especially
  the Workflow section)
- read other README_*.md files associated with the particular
  workflow step (in the top directory of this project)
- look in Group 1, 2 and 3 directories (ie. 1a_mkPrevStructs,
  1b_populatePrev, etc) for hints regarding how to invoke scripts
  and expected results)

